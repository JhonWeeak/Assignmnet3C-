﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assignment3C_
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var username = tbxUserName.Text;
            var password = tbxPassWord.Text;

            string filePath = "D:\\Data Strc and Design Patterns\\Assignment3C#\\user.txt";

            using (StreamReader reader = new StreamReader(new FileStream(filePath, FileMode.Open, FileAccess.Read)))
            {
                string line;
                bool loginSuccessful = false;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 2 && parts[0] == username && parts[1] == password)
                    {
                        loginSuccessful = true;
                        break;
                    }
                }

                if (loginSuccessful)
                {
                    MessageBox.Show("Login successful.");
                    this.Hide();
                    var mainForm = new MainForm();
                    mainForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Login failed.");
                }
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
