﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
namespace Assignment3C_
{
    public partial class AddStudent : Form
    {
        public event EventHandler StudentSaved;

        private List<Student> studentsList;
        public AddStudent(List<Student> students)
        {
            InitializeComponent();
            studentsList = students;
        }
        public bool IsEditMode { get; set; } = false;
        public Student OriginalStudent { get; set; }
        public AddStudent()
        {
            InitializeComponent();
        }

        private void AddStudent_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string id = tbxStudentID.Text.Trim();
            string firstName = tbxStudentFirstName.Text.Trim();
            string lastName = tbxStudentLastName.Text.Trim();
            string ageText = tbxStudentAge.Text.Trim();
            string gender = cbxStudentGender.SelectedItem?.ToString();
            string className = tbxClassName.Text.Trim();
            string grade = tbxStudentGrade.Text.Trim();

            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) ||
                string.IsNullOrWhiteSpace(ageText) || string.IsNullOrWhiteSpace(gender) || string.IsNullOrWhiteSpace(className) ||
                string.IsNullOrWhiteSpace(grade))
            {
                MessageBox.Show("ID, first name, last name, age, gender, class name, and grade are required.");
                return;
            }

            List<string> lines = File.ReadAllLines("D:\\Data Strc and Design Patterns\\Assignment3C#\\students.txt").ToList();

            if (IsEditMode)
            {
                var existingLine = lines.FirstOrDefault(line => line.StartsWith(OriginalStudent.Id + ","));
                if (existingLine != null)
                {
                    lines[lines.IndexOf(existingLine)] = $"{id},{firstName},{lastName},{ageText},{gender},{className},{grade}";
                }
            }
            else
            {
                lines.Add($"{id},{firstName},{lastName},{ageText},{gender},{className},{grade}");
            }

            File.WriteAllLines("D:\\Data Strc and Design Patterns\\Assignment3C#\\students.txt", lines);
            MessageBox.Show(IsEditMode ? "Student updated successfully." : "Student added successfully.");
            DialogResult = DialogResult.OK;
            MainForm mainForm = (MainForm)Application.OpenForms["MainForm"];
            mainForm?.UpdateDataGridView(studentsList);

            DialogResult = DialogResult.OK;
            this.Close();
            ((MainForm)Application.OpenForms["MainForm"]).LoadStudents();
        }
        public void LoadStudentInfo(Student student)
        {
            tbxStudentID.Text = student.Id;
            tbxStudentFirstName.Text = student.FirstName;
            tbxStudentLastName.Text = student.LastName;
            tbxStudentAge.Text = student.Age.ToString();
            cbxStudentGender.SelectedItem = student.Gender;
            tbxClassName.Text = student.ClassName;
            tbxStudentGrade.Text = student.Grade.ToString();
            IsEditMode = true;
            OriginalStudent = student;
            this.Text = "Edit Student";
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

