﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assignment3C_
{
    public partial class MainForm : Form
    {
        private List<Student> studentsList; // 声明私有字段

        public MainForm()
        {
            InitializeComponent();
            studentsList = new List<Student>(); // 初始化
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }

        public void LoadStudents()
        {
            string filePath = "D:\\Data Strc and Design Patterns\\Assignment3C#\\students.txt";

            using (StreamReader reader = new StreamReader(filePath))
            {
                studentsList.Clear();

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 7)
                    {
                        var student = new Student
                        {
                            Id = parts[0],
                            FirstName = parts[1],
                            LastName = parts[2],
                            Age = int.TryParse(parts[3], out int age) ? age : 0,
                            Gender = parts[4],
                            ClassName = parts[5],
                            Grade = parts[6]
                        };
                        studentsList.Add(student);
                    }
                }
            }

            dgvStudents.DataSource = studentsList;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddStudent addStudentForm = new AddStudent();

            addStudentForm.StudentSaved += AddStudentForm_StudentSaved;

            var dialogResult = addStudentForm.ShowDialog();
        }

        private void AddStudentForm_StudentSaved(object sender, EventArgs e)
        {
            LoadStudents();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student to delete.");
                return;
            }

            var selectedRow = dgvStudents.SelectedRows[0];
            string studentId = selectedRow.Cells["Id"].Value.ToString();

            var confirmResult = MessageBox.Show($"Are you sure to delete this student (ID: {studentId})?",
                                                 "Confirm Delete",
                                                 MessageBoxButtons.YesNo);
            if (confirmResult != DialogResult.Yes)
            {
                return;
            }

            {
                string filePath = "D:\\Data Strc and Design Patterns\\Assignment3C#\\students.txt";

                var lines = File.ReadAllLines(filePath).ToList();

                var lineToDelete = lines.FirstOrDefault(line => line.StartsWith(studentId + ","));
                if (lineToDelete != null)
                {
                    lines.Remove(lineToDelete);

                    File.WriteAllLines(filePath, lines);
                    MessageBox.Show("Student deleted successfully.");

                    LoadStudents();
                    UpdateDataGridView(studentsList);
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student to edit.");
                return;
            }

            var selectedRow = dgvStudents.SelectedRows[0];
            var studentToEdit = new Student
            {
                Id = selectedRow.Cells["Id"].Value.ToString(),
                FirstName = selectedRow.Cells["FirstName"].Value.ToString(),
                LastName = selectedRow.Cells["LastName"].Value.ToString(),
                Age = Convert.ToInt32(selectedRow.Cells["Age"].Value),
                Gender = selectedRow.Cells["Gender"].Value.ToString(),
                ClassName = selectedRow.Cells["ClassName"].Value.ToString(),
                Grade = selectedRow.Cells["Grade"].Value.ToString()
            };

            AddStudent editStudentForm = new AddStudent();
            editStudentForm.LoadStudentInfo(studentToEdit);
            if (editStudentForm.ShowDialog() == DialogResult.OK)
            {
                LoadStudents();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = tbxSearch.Text.Trim().ToLower();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a search term.");
                return;
            }

            var searchResults = studentsList.Where(student =>
                student.Id.ToLower().Contains(searchTerm) ||
                student.FirstName.ToLower().Contains(searchTerm) ||
                student.LastName.ToLower().Contains(searchTerm) ||
                student.Age.ToString().Contains(searchTerm) ||
                student.Gender.ToLower().Contains(searchTerm) ||
                student.ClassName.ToLower().Contains(searchTerm) ||
                student.Grade.ToString().Contains(searchTerm) 
                ).ToList();

            dgvStudents.DataSource = searchResults;
        }

        public void UpdateDataGridView(List<Student> students)
        {
            dgvStudents.DataSource = null;
            dgvStudents.DataSource = students;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LoadStudents();
        }
    }
}
