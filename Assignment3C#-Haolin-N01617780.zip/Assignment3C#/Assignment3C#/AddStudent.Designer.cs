﻿namespace Assignment3C_
{
    partial class AddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxStudentID = new System.Windows.Forms.TextBox();
            this.tbxStudentFirstName = new System.Windows.Forms.TextBox();
            this.tbxStudentAge = new System.Windows.Forms.TextBox();
            this.lblStudentID = new System.Windows.Forms.Label();
            this.lblStudentFirstName = new System.Windows.Forms.Label();
            this.lblStudentAge = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblStudentLastName = new System.Windows.Forms.Label();
            this.tbxStudentLastName = new System.Windows.Forms.TextBox();
            this.lblStudentGender = new System.Windows.Forms.Label();
            this.lblClassName = new System.Windows.Forms.Label();
            this.lblStudentGrade = new System.Windows.Forms.Label();
            this.tbxClassName = new System.Windows.Forms.TextBox();
            this.tbxStudentGrade = new System.Windows.Forms.TextBox();
            this.cbxStudentGender = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // tbxStudentID
            // 
            this.tbxStudentID.Location = new System.Drawing.Point(213, 27);
            this.tbxStudentID.Name = "tbxStudentID";
            this.tbxStudentID.Size = new System.Drawing.Size(224, 28);
            this.tbxStudentID.TabIndex = 0;
            // 
            // tbxStudentFirstName
            // 
            this.tbxStudentFirstName.Location = new System.Drawing.Point(213, 108);
            this.tbxStudentFirstName.Name = "tbxStudentFirstName";
            this.tbxStudentFirstName.Size = new System.Drawing.Size(224, 28);
            this.tbxStudentFirstName.TabIndex = 1;
            // 
            // tbxStudentAge
            // 
            this.tbxStudentAge.Location = new System.Drawing.Point(213, 242);
            this.tbxStudentAge.Name = "tbxStudentAge";
            this.tbxStudentAge.Size = new System.Drawing.Size(224, 28);
            this.tbxStudentAge.TabIndex = 2;
            // 
            // lblStudentID
            // 
            this.lblStudentID.AutoSize = true;
            this.lblStudentID.Location = new System.Drawing.Point(32, 37);
            this.lblStudentID.Name = "lblStudentID";
            this.lblStudentID.Size = new System.Drawing.Size(98, 18);
            this.lblStudentID.TabIndex = 3;
            this.lblStudentID.Text = "StudentID:";
            // 
            // lblStudentFirstName
            // 
            this.lblStudentFirstName.AutoSize = true;
            this.lblStudentFirstName.Location = new System.Drawing.Point(32, 111);
            this.lblStudentFirstName.Name = "lblStudentFirstName";
            this.lblStudentFirstName.Size = new System.Drawing.Size(161, 18);
            this.lblStudentFirstName.TabIndex = 4;
            this.lblStudentFirstName.Text = "StudentFirstName:";
            // 
            // lblStudentAge
            // 
            this.lblStudentAge.AutoSize = true;
            this.lblStudentAge.Location = new System.Drawing.Point(32, 245);
            this.lblStudentAge.Name = "lblStudentAge";
            this.lblStudentAge.Size = new System.Drawing.Size(107, 18);
            this.lblStudentAge.TabIndex = 5;
            this.lblStudentAge.Text = "StudentAge:";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(35, 505);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(116, 49);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(321, 505);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(116, 49);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblStudentLastName
            // 
            this.lblStudentLastName.AutoSize = true;
            this.lblStudentLastName.Location = new System.Drawing.Point(32, 173);
            this.lblStudentLastName.Name = "lblStudentLastName";
            this.lblStudentLastName.Size = new System.Drawing.Size(152, 18);
            this.lblStudentLastName.TabIndex = 8;
            this.lblStudentLastName.Text = "StudentLastName:";
            // 
            // tbxStudentLastName
            // 
            this.tbxStudentLastName.Location = new System.Drawing.Point(213, 173);
            this.tbxStudentLastName.Name = "tbxStudentLastName";
            this.tbxStudentLastName.Size = new System.Drawing.Size(224, 28);
            this.tbxStudentLastName.TabIndex = 9;
            // 
            // lblStudentGender
            // 
            this.lblStudentGender.AutoSize = true;
            this.lblStudentGender.Location = new System.Drawing.Point(32, 303);
            this.lblStudentGender.Name = "lblStudentGender";
            this.lblStudentGender.Size = new System.Drawing.Size(134, 18);
            this.lblStudentGender.TabIndex = 10;
            this.lblStudentGender.Text = "StudentGender:";
            // 
            // lblClassName
            // 
            this.lblClassName.AutoSize = true;
            this.lblClassName.Location = new System.Drawing.Point(32, 357);
            this.lblClassName.Name = "lblClassName";
            this.lblClassName.Size = new System.Drawing.Size(98, 18);
            this.lblClassName.TabIndex = 11;
            this.lblClassName.Text = "ClassName:";
            // 
            // lblStudentGrade
            // 
            this.lblStudentGrade.AutoSize = true;
            this.lblStudentGrade.Location = new System.Drawing.Point(32, 414);
            this.lblStudentGrade.Name = "lblStudentGrade";
            this.lblStudentGrade.Size = new System.Drawing.Size(125, 18);
            this.lblStudentGrade.TabIndex = 12;
            this.lblStudentGrade.Text = "StudentGrade:";
            // 
            // tbxClassName
            // 
            this.tbxClassName.Location = new System.Drawing.Point(213, 354);
            this.tbxClassName.Name = "tbxClassName";
            this.tbxClassName.Size = new System.Drawing.Size(224, 28);
            this.tbxClassName.TabIndex = 14;
            // 
            // tbxStudentGrade
            // 
            this.tbxStudentGrade.Location = new System.Drawing.Point(213, 411);
            this.tbxStudentGrade.Name = "tbxStudentGrade";
            this.tbxStudentGrade.Size = new System.Drawing.Size(224, 28);
            this.tbxStudentGrade.TabIndex = 15;
            // 
            // cbxStudentGender
            // 
            this.cbxStudentGender.FormattingEnabled = true;
            this.cbxStudentGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbxStudentGender.Location = new System.Drawing.Point(213, 303);
            this.cbxStudentGender.Name = "cbxStudentGender";
            this.cbxStudentGender.Size = new System.Drawing.Size(224, 26);
            this.cbxStudentGender.TabIndex = 16;
            // 
            // AddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 637);
            this.Controls.Add(this.cbxStudentGender);
            this.Controls.Add(this.tbxStudentGrade);
            this.Controls.Add(this.tbxClassName);
            this.Controls.Add(this.lblStudentGrade);
            this.Controls.Add(this.lblClassName);
            this.Controls.Add(this.lblStudentGender);
            this.Controls.Add(this.tbxStudentLastName);
            this.Controls.Add(this.lblStudentLastName);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblStudentAge);
            this.Controls.Add(this.lblStudentFirstName);
            this.Controls.Add(this.lblStudentID);
            this.Controls.Add(this.tbxStudentAge);
            this.Controls.Add(this.tbxStudentFirstName);
            this.Controls.Add(this.tbxStudentID);
            this.Name = "AddStudent";
            this.Text = "AddStudent";
            this.Load += new System.EventHandler(this.AddStudent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxStudentID;
        private System.Windows.Forms.TextBox tbxStudentFirstName;
        private System.Windows.Forms.TextBox tbxStudentAge;
        private System.Windows.Forms.Label lblStudentID;
        private System.Windows.Forms.Label lblStudentFirstName;
        private System.Windows.Forms.Label lblStudentAge;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblStudentLastName;
        private System.Windows.Forms.TextBox tbxStudentLastName;
        private System.Windows.Forms.Label lblStudentGender;
        private System.Windows.Forms.Label lblClassName;
        private System.Windows.Forms.Label lblStudentGrade;
        private System.Windows.Forms.TextBox tbxClassName;
        private System.Windows.Forms.TextBox tbxStudentGrade;
        private System.Windows.Forms.ComboBox cbxStudentGender;
    }
}